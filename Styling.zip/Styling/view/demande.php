<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--========== BOX ICONS ==========-->
    <link rel="stylesheet" href="view/assets/css/boxicons.min.css">
    <!--========== CSS ==========-->
    <title>Admin</title>
    <link rel="icon" href="view/assets/img/icons8-film-reel-50.png">


    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" />










</head>
<link rel="stylesheet" href="view/assets/css/bootstrap.min.css">
<!-- <link rel="stylesheet" href="../view/image/"> -->
<link rel="stylesheet" href="view/assets/css/main.css">
<link rel="stylesheet" href="../view/image/">
<!--========== HEADER ==========-->
<header class="header">
    <div class="header__container">
        <div class="header__login">
            <a href="?action=logout" name="logout"> <i class='bx bx-log-in '></i> <input onclick="document.getElementById('id01').style.display='block'" class="btn text-light" type="button" value="Sign out" /></a>
        </div>
        <!-- Login form -->
        <div id="id01" class="modal">

            <form class="modal-content animate" action="" method="post">
                <div class="imgcontainer">
                    <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
                    <h1>Sign In</h1>
                </div>



                <h5>Don't have an account? <a href=""> Sign up here!</a> </h5>

            </form>

        </div>

        <!-- Resister form -->
        <div id="id02" class="modal">

            <form class="modal-content animate" action="" method="post">
                <div class="imgcontainer">
                    <span onclick="document.getElementById('id02').style.display='none'" class="close" title="Close Modal">&times;</span>
                    <h1>Create account</h1>
                </div>

                <div class="container">
                    <label for="uname"><b>Username</b></label>
                    <input type="text" style=" color : whitesmoke; " name="uname" required>

                    <label for="psw"><b>Email</b></label>
                    <input type="email" style=" color : whitesmoke; " name="email" required>

                    <label for="psw"><b>Password </b></label>
                    <input type="password" style=" color : whitesmoke; " placeholder="at least 8 charcters" name="psw" required>

                    <label for="psw"><b>Password Confirm</b></label>
                    <input type="password" style=" color : whitesmoke; " name="psw1" required>



                    <button class="blr" type="submit" name="regist">Sign Up</button>

                </div>



            </form>
        </div>




        <a href="?action=auth" class="header__logo">Movie<span class="color-logo">time</span> </a>



        <div class="header__toggle">
            <i class="fa-solid fa-bars" id="header-toggle"></i>

        </div>
    </div>
</header>

<body>

<h1 class='text-center text-info text-capitalize m-5'>Mailbox</h1>
     <table class='table w-75 mx-auto table-bordered'>
          <thead class='table-dark text-center'>
               <tr>
                    <th>Email</th>
                    <th>Titre</th>
                    <th>Links</th>
                    
               </tr>
          </thead>
          <tbody>
                    
               <?php 
                       

                       $c= new mysqli("localhost","root","","pfe-movietime");
                       $r="select * from demande";
                       $res=$c->query($r);
                       while($row=$res->fetch_row()):
                         echo "<tr class=\"text-light\">
                              <th >$row[1]</th>
                              <td>$row[2]</td>
                              <th style=\"font-size:13px\">$row[3]</th>
                              <th><a class=\"btn btn-danger\" href=\"\"> <i class=\"fa  fa-lg fa-trash\"  aria-hidden=\"true\"></i>   </a></th>



                         </tr>";

                    endwhile;
               
               ?>
               
          </tbody>
     </table>

     <br>
     <a href="?action=auth" class="btn btn-secondary d-block w-25 mx-auto" > <i class='bx  bx-arrow-back' style='color:#ffffff'  ></i>Back to dashboard</a>

     
   
        
    
</body>

</html>